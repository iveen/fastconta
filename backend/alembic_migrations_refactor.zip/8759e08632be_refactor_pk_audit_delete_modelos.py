"""refactor_pk_audit_delete_modelos
Revision ID: 8759e08632be
Revises: 6ae007510c23
Create Date: 2026-07-06 12:46:23.642979
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import UUID

revision: str = '8759e08632be'
down_revision: Union[str, None] = '6ae007510c23'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# ============================================================
# HELPERS REUTILIZABLES
# ============================================================
SCHEMA = 'public'

def _qualified(table: str) -> str:
    return f"{SCHEMA}.{table}"

def _refactor_pk(op, table: str):
    """Convierte PK UUID → BIGINT + public_id UUID (reutiliza el UUID viejo como public_id)"""
    q = _qualified(table)
    # 1. Drop PK actual
    op.drop_constraint(f"{table}_pkey", table, type_='primary', schema=SCHEMA)
    # 2. Renombrar id → old_uuid_id
    op.alter_column(table, 'id', new_column_name='old_uuid_id', schema=SCHEMA)
    # 3. Agregar nuevo id BIGINT (nullable temporalmente)
    op.add_column(table, sa.Column('id', sa.BigInteger(), nullable=True), schema=SCHEMA)
    # 4. Crear secuencia y poblar
    op.execute(f"CREATE SEQUENCE {_qualified(table + '_id_seq')}")
    op.execute(f"UPDATE {q} SET id = nextval('{_qualified(table + '_id_seq')}')")
    op.execute(f"ALTER SEQUENCE {_qualified(table + '_id_seq')} OWNED BY {q}.id")
    # 5. Hacer NOT NULL y PK
    op.alter_column(table, 'id', nullable=False, schema=SCHEMA)
    op.create_primary_key(f"{table}_pkey", table, ['id'], schema=SCHEMA)
    # 6. Agregar public_id (reutilizando old_uuid_id)
    op.add_column(table, sa.Column('public_id', UUID(as_uuid=True), nullable=True), schema=SCHEMA)
    op.execute(f"UPDATE {q} SET public_id = old_uuid_id")
    op.alter_column(table, 'public_id', nullable=False, schema=SCHEMA)
    op.create_unique_constraint(f"uq_{table}_public_id", table, ['public_id'], schema=SCHEMA)
    op.create_index(f"ix_{table}_public_id", table, ['public_id'], schema=SCHEMA)


def _change_col_to_bigint(op, table: str, column: str):
    """Cambia una columna de UUID a BigInteger"""
    op.alter_column(
        table, column,
        type_=sa.BigInteger(),
        existing_type=UUID(as_uuid=True),
        schema=SCHEMA
    )


def _add_soft_delete(op, table: str, had_is_active: bool = False, had_activo: bool = False):
    """Agrega columnas de SoftDelete (is_active + deleted_at)"""
    if had_activo:
        # Renombrar activo → is_active
        op.alter_column(table, 'activo', new_column_name='is_active', schema=SCHEMA)
        op.add_column(table, sa.Column('deleted_at', sa.DateTime(timezone=True), nullable=True), schema=SCHEMA)
    elif not had_is_active:
        op.add_column(table, sa.Column('is_active', sa.Boolean(), nullable=False, server_default='true'), schema=SCHEMA)
        op.add_column(table, sa.Column('deleted_at', sa.DateTime(timezone=True), nullable=True), schema=SCHEMA)
    else:
        # Solo agregar deleted_at (is_active ya existe)
        op.add_column(table, sa.Column('deleted_at', sa.DateTime(timezone=True), nullable=True), schema=SCHEMA)


def _add_auditable_create(op, table: str, drop_created_at: bool = False):
    """Agrega created_by (AuditableCreate)"""
    if drop_created_at:
        op.drop_column(table, 'created_at', schema=SCHEMA)
    op.add_column(
        table,
        sa.Column('created_by', sa.BigInteger(),
                  sa.ForeignKey(f'{SCHEMA}.users.id', ondelete='SET NULL'),
                  nullable=True),
        schema=SCHEMA
    )


def _add_auditable_full(op, table: str, drop_created_at: bool = False, drop_updated_at: bool = False):
    """Agrega created_by + updated_by (AuditableFull)"""
    if drop_created_at:
        op.drop_column(table, 'created_at', schema=SCHEMA)
    if drop_updated_at:
        op.drop_column(table, 'updated_at', schema=SCHEMA)
    op.add_column(
        table,
        sa.Column('created_by', sa.BigInteger(),
                  sa.ForeignKey(f'{SCHEMA}.users.id', ondelete='SET NULL'),
                  nullable=True),
        schema=SCHEMA
    )
    op.add_column(
        table,
        sa.Column('updated_by', sa.BigInteger(),
                  sa.ForeignKey(f'{SCHEMA}.users.id', ondelete='SET NULL'),
                  nullable=True),
        schema=SCHEMA
    )


def _drop_fk_if_exists(op, table: str, constraint: str):
    """Drop FK de forma segura"""
    try:
        op.drop_constraint(constraint, table, schema=SCHEMA, type_='foreignkey')
    except Exception:
        op.execute(f"""
            DO $$ BEGIN
                ALTER TABLE {_qualified(table)} DROP CONSTRAINT IF EXISTS {constraint};
            END $$;
        """)


# ============================================================
# UPGRADE
# ============================================================
def upgrade() -> None:
    # --------------------------------------------------------
    # FASE 1: Drop todas las FKs (para poder cambiar tipos)
    # --------------------------------------------------------
    # Municipio
    _drop_fk_if_exists(op, 'municipios', 'municipios_departamento_id_fkey')
    # User
    _drop_fk_if_exists(op, 'users', 'users_tenant_id_fkey')
    _drop_fk_if_exists(op, 'users', 'users_role_id_fkey')
    # UserEmpresa
    _drop_fk_if_exists(op, 'user_empresas', 'user_empresas_user_id_fkey')
    _drop_fk_if_exists(op, 'user_empresas', 'user_empresas_tenant_id_fkey')
    # RegimenImpuestoConfig
    _drop_fk_if_exists(op, 'regimen_impuesto_config', 'regimen_impuesto_config_regimen_id_fkey')
    _drop_fk_if_exists(op, 'regimen_impuesto_config', 'regimen_impuesto_config_impuesto_id_fkey')
    # RegimenDteConfig
    _drop_fk_if_exists(op, 'regimen_dte_config', 'regimen_dte_config_regimen_id_fkey')
    _drop_fk_if_exists(op, 'regimen_dte_config', 'regimen_dte_config_dte_id_fkey')
    # FormularioSat (auto-ref)
    _drop_fk_if_exists(op, 'formularios_sat', 'formularios_sat_formulario_padre_id_fkey')
    # SeccionFormulario
    _drop_fk_if_exists(op, 'secciones_formulario', 'secciones_formulario_formulario_id_fkey')
    # CasillaSat
    _drop_fk_if_exists(op, 'casillas_sat', 'casillas_sat_seccion_id_fkey')
    # ReglaFiltradoFactura
    _drop_fk_if_exists(op, 'reglas_filtrado_factura', 'reglas_filtrado_factura_casilla_id_fkey')
    # ExclusionCasilla
    _drop_fk_if_exists(op, 'exclusiones_casilla', 'exclusiones_casilla_casilla_id_fkey')
    # RegimenFormularioSat
    _drop_fk_if_exists(op, 'regimenes_formularios_sat', 'regimenes_formularios_sat_regimen_id_fkey')
    _drop_fk_if_exists(op, 'regimenes_formularios_sat', 'regimenes_formularios_sat_formulario_id_fkey')
    # MapeoCasillaCuenta
    _drop_fk_if_exists(op, 'mapeo_casilla_cuenta', 'mapeo_casilla_cuenta_casilla_id_fkey')
    _drop_fk_if_exists(op, 'mapeo_casilla_cuenta', 'mapeo_casilla_cuenta_tenant_id_fkey')
    # Auditoría (created_by/updated_by apuntan a users.id)
    for tbl in ['tipos_dte', 'catalogo_monedas', 'catalogo_impuestos_especiales',
                'tipos_persona', 'departamentos', 'municipios', 'actividades_economicas_sat',
                'categorias_activos_fijos', 'regimenes_fiscales', 'regimen_impuesto_config',
                'regimen_dte_config', 'formularios_sat', 'secciones_formulario', 'casillas_sat',
                'reglas_filtrado_factura', 'exclusiones_casilla', 'regimenes_formularios_sat',
                'mapeo_casilla_cuenta']:
        _drop_fk_if_exists(op, tbl, f'{tbl}_created_by_fkey')
        _drop_fk_if_exists(op, tbl, f'{tbl}_updated_by_fkey')

    # --------------------------------------------------------
    # FASE 2: Refactorizar PKs de todas las tablas
    # --------------------------------------------------------
    tables_global = [
        'registration_attempts', 'tipos_dte', 'catalogo_monedas', 'catalogo_impuestos_especiales',
        'tipos_libro', 'estados_libro', 'tipos_persona', 'tipos_domicilio',
        'departamentos', 'municipios', 'actividades_economicas_sat',
        'roles', 'tenants', 'users', 'user_empresas', 'categorias_activos_fijos',
        'regimenes_fiscales', 'catalogo_impuestos', 'regimen_impuesto_config', 'regimen_dte_config',
        'formularios_sat', 'secciones_formulario', 'casillas_sat',
        'reglas_filtrado_factura', 'exclusiones_casilla', 'regimenes_formularios_sat',
        'mapeo_casilla_cuenta'
    ]
    for t in tables_global:
        _refactor_pk(op, t)

    # --------------------------------------------------------
    # FASE 3: Cambiar tipos de columnas FK
    # --------------------------------------------------------
    _change_col_to_bigint(op, 'municipios', 'departamento_id')
    _change_col_to_bigint(op, 'users', 'tenant_id')
    _change_col_to_bigint(op, 'users', 'role_id')
    _change_col_to_bigint(op, 'user_empresas', 'user_id')
    _change_col_to_bigint(op, 'user_empresas', 'tenant_id')
    _change_col_to_bigint(op, 'regimen_impuesto_config', 'regimen_id')
    _change_col_to_bigint(op, 'regimen_impuesto_config', 'impuesto_id')
    _change_col_to_bigint(op, 'regimen_dte_config', 'regimen_id')
    _change_col_to_bigint(op, 'regimen_dte_config', 'dte_id')
    _change_col_to_bigint(op, 'formularios_sat', 'formulario_padre_id')
    _change_col_to_bigint(op, 'secciones_formulario', 'formulario_id')
    _change_col_to_bigint(op, 'casillas_sat', 'seccion_id')
    _change_col_to_bigint(op, 'reglas_filtrado_factura', 'casilla_id')
    _change_col_to_bigint(op, 'exclusiones_casilla', 'casilla_id')
    _change_col_to_bigint(op, 'regimenes_formularios_sat', 'regimen_id')
    _change_col_to_bigint(op, 'regimenes_formularios_sat', 'formulario_id')
    _change_col_to_bigint(op, 'mapeo_casilla_cuenta', 'casilla_id')
    _change_col_to_bigint(op, 'mapeo_casilla_cuenta', 'tenant_id')

    # --------------------------------------------------------
    # FASE 4: Agregar columnas de SoftDelete + Audit
    # --------------------------------------------------------
    # Tenant: tenía is_active + created_at → agrega deleted_at + audit full
    _add_soft_delete(op, 'tenants', had_is_active=True)
    _add_auditable_full(op, 'tenants', drop_created_at=True)

    # RegistrationAttempt: no tenía nada, solo PK refactor (sin audit ni soft delete)

    # TipoDTE: tenía activo + created_at + updated_at
    _add_soft_delete(op, 'tipos_dte', had_activo=True)
    _add_auditable_full(op, 'tipos_dte', drop_created_at=True, drop_updated_at=True)

    # CatalogoMoneda: tenía activo + created_at + updated_at
    _add_soft_delete(op, 'catalogo_monedas', had_activo=True)
    _add_auditable_full(op, 'catalogo_monedas', drop_created_at=True, drop_updated_at=True)

    # CatalogoImpuestoEspecial: tenía activo + creado_en
    _add_soft_delete(op, 'catalogo_impuestos_especiales', had_activo=True)
    op.drop_column('catalogo_impuestos_especiales', 'creado_en', schema=SCHEMA)
    _add_auditable_create(op, 'catalogo_impuestos_especiales')

    # TipoLibro: sin campos especiales
    _add_soft_delete(op, 'tipos_libro')
    _add_auditable_create(op, 'tipos_libro')

    # EstadoLibro
    _add_soft_delete(op, 'estados_libro')
    _add_auditable_create(op, 'estados_libro')

    # TipoPersona
    _add_soft_delete(op, 'tipos_persona')
    _add_auditable_full(op, 'tipos_persona')

    # TipoDomicilio
    _add_soft_delete(op, 'tipos_domicilio')
    _add_auditable_create(op, 'tipos_domicilio')

    # Departamento
    _add_soft_delete(op, 'departamentos')
    _add_auditable_full(op, 'departamentos')

    # Municipio
    _add_soft_delete(op, 'municipios')
    _add_auditable_full(op, 'municipios')

    # ActividadEconomicaSAT: tenía activa + created_at
    _add_soft_delete(op, 'actividades_economicas_sat', had_activo=False)
    # Renombrar activa → is_active
    op.alter_column('actividades_economicas_sat', 'activa', new_column_name='is_active', schema=SCHEMA)
    _add_auditable_full(op, 'actividades_economicas_sat', drop_created_at=True)

    # Role
    _add_soft_delete(op, 'roles')
    _add_auditable_create(op, 'roles')

    # User: tenía is_active + created_at
    _add_soft_delete(op, 'users', had_is_active=True)
    _add_auditable_create(op, 'users', drop_created_at=True)

    # UserEmpresa: tenía activo + created_at
    op.alter_column('user_empresas', 'activo', new_column_name='is_active', schema=SCHEMA)
    op.add_column('user_empresas', sa.Column('deleted_at', sa.DateTime(timezone=True), nullable=True), schema=SCHEMA)
    _add_auditable_full(op, 'user_empresas', drop_created_at=True)

    # CategoriaActivoFijo: tenía is_active + created_at
    _add_soft_delete(op, 'categorias_activos_fijos', had_is_active=True)
    _add_auditable_full(op, 'categorias_activos_fijos', drop_created_at=True)

    # RegimenFiscal: tenía is_active
    _add_soft_delete(op, 'regimenes_fiscales', had_is_active=True)
    _add_auditable_full(op, 'regimenes_fiscales')

    # CatalogoImpuesto: tenía is_active + created_at
    _add_soft_delete(op, 'catalogo_impuestos', had_is_active=True)
    _add_auditable_create(op, 'catalogo_impuestos', drop_created_at=True)

    # RegimenImpuestoConfig: tenía created_at
    _add_soft_delete(op, 'regimen_impuesto_config')
    _add_auditable_create(op, 'regimen_impuesto_config', drop_created_at=True)

    # RegimenDteConfig
    _add_soft_delete(op, 'regimen_dte_config')
    _add_auditable_create(op, 'regimen_dte_config')

    # FormularioSat: ya tenía AuditableFull
    _add_soft_delete(op, 'formularios_sat')
    _add_auditable_full(op, 'formularios_sat')

    # SeccionFormulario: ya tenía AuditableFull
    _add_soft_delete(op, 'secciones_formulario')
    _add_auditable_full(op, 'secciones_formulario')

    # CasillaSat: ya tenía AuditableFull
    _add_soft_delete(op, 'casillas_sat')
    _add_auditable_full(op, 'casillas_sat')

    # ReglaFiltradoFactura: tenía es_activa + AuditableFull
    op.alter_column('reglas_filtrado_factura', 'es_activa', new_column_name='is_active', schema=SCHEMA)
    op.add_column('reglas_filtrado_factura', sa.Column('deleted_at', sa.DateTime(timezone=True), nullable=True), schema=SCHEMA)
    _add_auditable_full(op, 'reglas_filtrado_factura')

    # ExclusionCasilla: tenía es_activa + AuditableFull
    op.alter_column('exclusiones_casilla', 'es_activa', new_column_name='is_active', schema=SCHEMA)
    op.add_column('exclusiones_casilla', sa.Column('deleted_at', sa.DateTime(timezone=True), nullable=True), schema=SCHEMA)
    _add_auditable_full(op, 'exclusiones_casilla')

    # RegimenFormularioSat: ya tenía AuditableFull
    _add_soft_delete(op, 'regimenes_formularios_sat')
    _add_auditable_full(op, 'regimenes_formularios_sat')

    # MapeoCasillaCuenta: ya tenía AuditableFull
    _add_soft_delete(op, 'mapeo_casilla_cuenta')
    _add_auditable_full(op, 'mapeo_casilla_cuenta')

    # --------------------------------------------------------
    # FASE 5: Recrear todas las FKs
    # --------------------------------------------------------
    op.create_foreign_key('municipios_departamento_id_fkey', 'municipios', 'departamentos',
                          ['departamento_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('users_tenant_id_fkey', 'users', 'tenants',
                          ['tenant_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('users_role_id_fkey', 'users', 'roles',
                          ['role_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('user_empresas_user_id_fkey', 'user_empresas', 'users',
                          ['user_id'], ['id'], ondelete='CASCADE', source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('user_empresas_tenant_id_fkey', 'user_empresas', 'tenants',
                          ['tenant_id'], ['id'], ondelete='CASCADE', source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('regimen_impuesto_config_regimen_id_fkey', 'regimen_impuesto_config', 'regimenes_fiscales',
                          ['regimen_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('regimen_impuesto_config_impuesto_id_fkey', 'regimen_impuesto_config', 'catalogo_impuestos',
                          ['impuesto_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('regimen_dte_config_regimen_id_fkey', 'regimen_dte_config', 'regimenes_fiscales',
                          ['regimen_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('regimen_dte_config_dte_id_fkey', 'regimen_dte_config', 'tipos_dte',
                          ['dte_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('formularios_sat_formulario_padre_id_fkey', 'formularios_sat', 'formularios_sat',
                          ['formulario_padre_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('secciones_formulario_formulario_id_fkey', 'secciones_formulario', 'formularios_sat',
                          ['formulario_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('casillas_sat_seccion_id_fkey', 'casillas_sat', 'secciones_formulario',
                          ['seccion_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('reglas_filtrado_factura_casilla_id_fkey', 'reglas_filtrado_factura', 'casillas_sat',
                          ['casilla_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('exclusiones_casilla_casilla_id_fkey', 'exclusiones_casilla', 'casillas_sat',
                          ['casilla_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('regimenes_formularios_sat_regimen_id_fkey', 'regimenes_formularios_sat', 'regimenes_fiscales',
                          ['regimen_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('regimenes_formularios_sat_formulario_id_fkey', 'regimenes_formularios_sat', 'formularios_sat',
                          ['formulario_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('mapeo_casilla_cuenta_casilla_id_fkey', 'mapeo_casilla_cuenta', 'casillas_sat',
                          ['casilla_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('mapeo_casilla_cuenta_tenant_id_fkey', 'mapeo_casilla_cuenta', 'tenants',
                          ['tenant_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)

    # --------------------------------------------------------
    # FASE 6: Eliminar old_uuid_id (ya no se necesita)
    # --------------------------------------------------------
    for t in tables_global:
        op.drop_column(t, 'old_uuid_id', schema=SCHEMA)


# ============================================================
# DOWNGRADE
# ============================================================
def downgrade() -> None:
    # --------------------------------------------------------
    # FASE 1: Drop FKs actuales
    # --------------------------------------------------------
    fks_to_drop = [
        ('municipios', 'municipios_departamento_id_fkey'),
        ('users', 'users_tenant_id_fkey'), ('users', 'users_role_id_fkey'),
        ('user_empresas', 'user_empresas_user_id_fkey'), ('user_empresas', 'user_empresas_tenant_id_fkey'),
        ('regimen_impuesto_config', 'regimen_impuesto_config_regimen_id_fkey'),
        ('regimen_impuesto_config', 'regimen_impuesto_config_impuesto_id_fkey'),
        ('regimen_dte_config', 'regimen_dte_config_regimen_id_fkey'),
        ('regimen_dte_config', 'regimen_dte_config_dte_id_fkey'),
        ('formularios_sat', 'formularios_sat_formulario_padre_id_fkey'),
        ('secciones_formulario', 'secciones_formulario_formulario_id_fkey'),
        ('casillas_sat', 'casillas_sat_seccion_id_fkey'),
        ('reglas_filtrado_factura', 'reglas_filtrado_factura_casilla_id_fkey'),
        ('exclusiones_casilla', 'exclusiones_casilla_casilla_id_fkey'),
        ('regimenes_formularios_sat', 'regimenes_formularios_sat_regimen_id_fkey'),
        ('regimenes_formularios_sat', 'regimenes_formularios_sat_formulario_id_fkey'),
        ('mapeo_casilla_cuenta', 'mapeo_casilla_cuenta_casilla_id_fkey'),
        ('mapeo_casilla_cuenta', 'mapeo_casilla_cuenta_tenant_id_fkey'),
    ]
    for tbl, fk in fks_to_drop:
        _drop_fk_if_exists(op, tbl, fk)

    # Drop FKs de auditoría
    for tbl in ['tipos_dte', 'catalogo_monedas', 'catalogo_impuestos_especiales',
                'tipos_persona', 'departamentos', 'municipios', 'actividades_economicas_sat',
                'categorias_activos_fijos', 'regimenes_fiscales', 'regimen_impuesto_config',
                'regimen_dte_config', 'formularios_sat', 'secciones_formulario', 'casillas_sat',
                'reglas_filtrado_factura', 'exclusiones_casilla', 'regimenes_formularios_sat',
                'mapeo_casilla_cuenta']:
        _drop_fk_if_exists(op, tbl, f'{tbl}_created_by_fkey')
        _drop_fk_if_exists(op, tbl, f'{tbl}_updated_by_fkey')

    # --------------------------------------------------------
    # FASE 2: Drop columnas de mixins (audit + soft delete)
    # --------------------------------------------------------
    # Tablas con AuditableFull (created_by + updated_by)
    for tbl in ['tenants', 'tipos_dte', 'catalogo_monedas', 'tipos_persona',
                'departamentos', 'municipios', 'actividades_economicas_sat',
                'categorias_activos_fijos', 'regimenes_fiscales',
                'formularios_sat', 'secciones_formulario', 'casillas_sat',
                'reglas_filtrado_factura', 'exclusiones_casilla',
                'regimenes_formularios_sat', 'mapeo_casilla_cuenta', 'user_empresas']:
        op.drop_column(tbl, 'created_by', schema=SCHEMA)
        op.drop_column(tbl, 'updated_by', schema=SCHEMA)

    # Tablas con AuditableCreate (solo created_by)
    for tbl in ['catalogo_impuestos_especiales', 'tipos_libro', 'estados_libro',
                'tipos_domicilio', 'roles', 'users', 'catalogo_impuestos',
                'regimen_impuesto_config', 'regimen_dte_config']:
        op.drop_column(tbl, 'created_by', schema=SCHEMA)

    # Drop deleted_at de todas las tablas con SoftDelete
    soft_delete_tables = [
        'tenants', 'tipos_dte', 'catalogo_monedas', 'catalogo_impuestos_especiales',
        'tipos_libro', 'estados_libro', 'tipos_persona', 'tipos_domicilio',
        'departamentos', 'municipios', 'actividades_economicas_sat',
        'roles', 'users', 'user_empresas', 'categorias_activos_fijos',
        'regimenes_fiscales', 'catalogo_impuestos', 'regimen_impuesto_config', 'regimen_dte_config',
        'formularios_sat', 'secciones_formulario', 'casillas_sat',
        'reglas_filtrado_factura', 'exclusiones_casilla', 'regimenes_formularios_sat',
        'mapeo_casilla_cuenta'
    ]
    for tbl in soft_delete_tables:
        op.drop_column(tbl, 'deleted_at', schema=SCHEMA)

    # --------------------------------------------------------
    # FASE 3: Restaurar columnas eliminadas (created_at, updated_at, activo, etc.)
    # --------------------------------------------------------
    # Tenants: restaurar created_at
    op.add_column('tenants', sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()), schema=SCHEMA)

    # TipoDTE: restaurar activo, created_at, updated_at (renombrar is_active → activo)
    op.alter_column('tipos_dte', 'is_active', new_column_name='activo', schema=SCHEMA)
    op.add_column('tipos_dte', sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()), schema=SCHEMA)
    op.add_column('tipos_dte', sa.Column('updated_at', sa.DateTime(timezone=True)), schema=SCHEMA)

    # CatalogoMoneda
    op.alter_column('catalogo_monedas', 'is_active', new_column_name='activo', schema=SCHEMA)
    op.add_column('catalogo_monedas', sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()), schema=SCHEMA)
    op.add_column('catalogo_monedas', sa.Column('updated_at', sa.DateTime(timezone=True)), schema=SCHEMA)

    # CatalogoImpuestoEspecial
    op.alter_column('catalogo_impuestos_especiales', 'is_active', new_column_name='activo', schema=SCHEMA)
    op.add_column('catalogo_impuestos_especiales', sa.Column('creado_en', sa.DateTime(timezone=True), server_default=sa.func.now()), schema=SCHEMA)

    # ActividadEconomicaSAT
    op.alter_column('actividades_economicas_sat', 'is_active', new_column_name='activa', schema=SCHEMA)
    op.add_column('actividades_economicas_sat', sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()), schema=SCHEMA)

    # User
    op.add_column('users', sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()), schema=SCHEMA)

    # UserEmpresa
    op.alter_column('user_empresas', 'is_active', new_column_name='activo', schema=SCHEMA)
    op.add_column('user_empresas', sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()), schema=SCHEMA)

    # CategoriaActivoFijo
    op.add_column('categorias_activos_fijos', sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()), schema=SCHEMA)

    # CatalogoImpuesto
    op.add_column('catalogo_impuestos', sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()), schema=SCHEMA)

    # RegimenImpuestoConfig
    op.add_column('regimen_impuesto_config', sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()), schema=SCHEMA)

    # ReglaFiltradoFactura
    op.alter_column('reglas_filtrado_factura', 'is_active', new_column_name='es_activa', schema=SCHEMA)

    # ExclusionCasilla
    op.alter_column('exclusiones_casilla', 'is_active', new_column_name='es_activa', schema=SCHEMA)

    # --------------------------------------------------------
    # FASE 4: Revertir PKs (BIGINT → UUID)
    # --------------------------------------------------------
    tables_global = [
        'registration_attempts', 'tipos_dte', 'catalogo_monedas', 'catalogo_impuestos_especiales',
        'tipos_libro', 'estados_libro', 'tipos_persona', 'tipos_domicilio',
        'departamentos', 'municipios', 'actividades_economicas_sat',
        'roles', 'tenants', 'users', 'user_empresas', 'categorias_activos_fijos',
        'regimenes_fiscales', 'catalogo_impuestos', 'regimen_impuesto_config', 'regimen_dte_config',
        'formularios_sat', 'secciones_formulario', 'casillas_sat',
        'reglas_filtrado_factura', 'exclusiones_casilla', 'regimenes_formularios_sat',
        'mapeo_casilla_cuenta'
    ]
    for t in tables_global:
        q = _qualified(t)
        # Drop PK actual (BIGINT)
        op.drop_constraint(f"{t}_pkey", t, type_='primary', schema=SCHEMA)
        # Drop índice y unique de public_id
        op.drop_index(f"ix_{t}_public_id", table_name=t, schema=SCHEMA)
        op.drop_constraint(f"uq_{t}_public_id", t, schema=SCHEMA, type_='unique')
        # Drop columnas id (BIGINT) y public_id
        op.drop_column(t, 'id', schema=SCHEMA)
        op.drop_column(t, 'public_id', schema=SCHEMA)
        # Drop secuencia
        op.execute(f"DROP SEQUENCE IF EXISTS {_qualified(t + '_id_seq')}")
        # Renombrar old_uuid_id → id
        op.alter_column(t, 'old_uuid_id', new_column_name='id', schema=SCHEMA)
        # Recrear PK
        op.create_primary_key(f"{t}_pkey", t, ['id'], schema=SCHEMA)

    # --------------------------------------------------------
    # FASE 5: Revertir tipos de columnas FK (BigInteger → UUID)
    # --------------------------------------------------------
    fk_cols_to_revert = [
        ('municipios', 'departamento_id'),
        ('users', 'tenant_id'), ('users', 'role_id'),
        ('user_empresas', 'user_id'), ('user_empresas', 'tenant_id'),
        ('regimen_impuesto_config', 'regimen_id'), ('regimen_impuesto_config', 'impuesto_id'),
        ('regimen_dte_config', 'regimen_id'), ('regimen_dte_config', 'dte_id'),
        ('formularios_sat', 'formulario_padre_id'),
        ('secciones_formulario', 'formulario_id'),
        ('casillas_sat', 'seccion_id'),
        ('reglas_filtrado_factura', 'casilla_id'),
        ('exclusiones_casilla', 'casilla_id'),
        ('regimenes_formularios_sat', 'regimen_id'), ('regimenes_formularios_sat', 'formulario_id'),
        ('mapeo_casilla_cuenta', 'casilla_id'), ('mapeo_casilla_cuenta', 'tenant_id'),
    ]
    for tbl, col in fk_cols_to_revert:
        op.alter_column(tbl, col, type_=UUID(as_uuid=True), existing_type=sa.BigInteger(), schema=SCHEMA)

    # --------------------------------------------------------
    # FASE 6: Recrear FKs originales
    # --------------------------------------------------------
    op.create_foreign_key('municipios_departamento_id_fkey', 'municipios', 'departamentos',
                          ['departamento_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('users_tenant_id_fkey', 'users', 'tenants',
                          ['tenant_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('users_role_id_fkey', 'users', 'roles',
                          ['role_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('user_empresas_user_id_fkey', 'user_empresas', 'users',
                          ['user_id'], ['id'], ondelete='CASCADE', source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('user_empresas_tenant_id_fkey', 'user_empresas', 'tenants',
                          ['tenant_id'], ['id'], ondelete='CASCADE', source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('regimen_impuesto_config_regimen_id_fkey', 'regimen_impuesto_config', 'regimenes_fiscales',
                          ['regimen_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('regimen_impuesto_config_impuesto_id_fkey', 'regimen_impuesto_config', 'catalogo_impuestos',
                          ['impuesto_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('regimen_dte_config_regimen_id_fkey', 'regimen_dte_config', 'regimenes_fiscales',
                          ['regimen_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('regimen_dte_config_dte_id_fkey', 'regimen_dte_config', 'tipos_dte',
                          ['dte_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('formularios_sat_formulario_padre_id_fkey', 'formularios_sat', 'formularios_sat',
                          ['formulario_padre_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('secciones_formulario_formulario_id_fkey', 'secciones_formulario', 'formularios_sat',
                          ['formulario_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('casillas_sat_seccion_id_fkey', 'casillas_sat', 'secciones_formulario',
                          ['seccion_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('reglas_filtrado_factura_casilla_id_fkey', 'reglas_filtrado_factura', 'casillas_sat',
                          ['casilla_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('exclusiones_casilla_casilla_id_fkey', 'exclusiones_casilla', 'casillas_sat',
                          ['casilla_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('regimenes_formularios_sat_regimen_id_fkey', 'regimenes_formularios_sat', 'regimenes_fiscales',
                          ['regimen_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('regimenes_formularios_sat_formulario_id_fkey', 'regimenes_formularios_sat', 'formularios_sat',
                          ['formulario_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('mapeo_casilla_cuenta_casilla_id_fkey', 'mapeo_casilla_cuenta', 'casillas_sat',
                          ['casilla_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)
    op.create_foreign_key('mapeo_casilla_cuenta_tenant_id_fkey', 'mapeo_casilla_cuenta', 'tenants',
                          ['tenant_id'], ['id'], source_schema=SCHEMA, referent_schema=SCHEMA)