"""refactor_pk_audit_delete_modelos_tenant
Revision ID: e0ddcd14eb77
Revises: 73831a4c2c00
Create Date: 2026-07-06 12:46:44.843587
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import UUID

revision: str = 'e0ddcd14eb77'
down_revision: Union[str, None] = '73831a4c2c00'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# ============================================================
# HELPERS (mismos que en la migración global)
# ============================================================
def _refactor_pk(op, table: str, schema: str = None):
    q = f"{schema}.{table}" if schema else table
    schema_prefix = f"{schema}." if schema else ""
    # Drop PK actual
    op.drop_constraint(f"{table}_pkey", table, type_='primary', schema=schema)
    # Renombrar id → old_uuid_id
    op.alter_column(table, 'id', new_column_name='old_uuid_id', schema=schema)
    # Agregar nuevo id BIGINT
    op.add_column(table, sa.Column('id', sa.BigInteger(), nullable=True), schema=schema)
    # Crear secuencia y poblar
    op.execute(f"CREATE SEQUENCE {schema_prefix}{table}_id_seq")
    op.execute(f"UPDATE {q} SET id = nextval('{schema_prefix}{table}_id_seq')")
    op.execute(f"ALTER SEQUENCE {schema_prefix}{table}_id_seq OWNED BY {q}.id")
    # NOT NULL + PK
    op.alter_column(table, 'id', nullable=False, schema=schema)
    op.create_primary_key(f"{table}_pkey", table, ['id'], schema=schema)
    # public_id
    op.add_column(table, sa.Column('public_id', UUID(as_uuid=True), nullable=True), schema=schema)
    op.execute(f"UPDATE {q} SET public_id = old_uuid_id")
    op.alter_column(table, 'public_id', nullable=False, schema=schema)
    op.create_unique_constraint(f"uq_{table}_public_id", table, ['public_id'], schema=schema)
    op.create_index(f"ix_{table}_public_id", table, ['public_id'], schema=schema)


def _change_col_to_bigint(op, table: str, column: str, schema: str = None):
    op.alter_column(table, column, type_=sa.BigInteger(),
                    existing_type=UUID(as_uuid=True), schema=schema)


def _add_soft_delete(op, table: str, schema: str = None,
                     had_is_active: bool = False, had_activo: bool = False,
                     had_es_activo: bool = False, had_activa: bool = False):
    if had_activo:
        op.alter_column(table, 'activo', new_column_name='is_active', schema=schema)
    elif had_es_activo:
        op.alter_column(table, 'es_activo', new_column_name='is_active', schema=schema)
    elif had_activa:
        op.alter_column(table, 'activa', new_column_name='is_active', schema=schema)
    elif not had_is_active:
        op.add_column(table, sa.Column('is_active', sa.Boolean(), nullable=False, server_default='true'), schema=schema)
    op.add_column(table, sa.Column('deleted_at', sa.DateTime(timezone=True), nullable=True), schema=schema)


def _add_auditable_full(op, table: str, schema: str = None,
                        drop_created_at: bool = False, drop_updated_at: bool = False):
    if drop_created_at:
        op.drop_column(table, 'created_at', schema=schema)
    if drop_updated_at:
        op.drop_column(table, 'updated_at', schema=schema)
    op.add_column(table, sa.Column('created_by', sa.BigInteger(),
                                   sa.ForeignKey('public.users.id', ondelete='SET NULL'),
                                   nullable=True), schema=schema)
    op.add_column(table, sa.Column('updated_by', sa.BigInteger(),
                                   sa.ForeignKey('public.users.id', ondelete='SET NULL'),
                                   nullable=True), schema=schema)


def _add_auditable_create(op, table: str, schema: str = None, drop_created_at: bool = False):
    if drop_created_at:
        op.drop_column(table, 'created_at', schema=schema)
    op.add_column(table, sa.Column('created_by', sa.BigInteger(),
                                   sa.ForeignKey('public.users.id', ondelete='SET NULL'),
                                   nullable=True), schema=schema)


def _drop_fk(op, table: str, constraint: str, schema: str = None):
    try:
        op.drop_constraint(constraint, table, schema=schema, type_='foreignkey')
    except Exception:
        q = f"{schema}.{table}" if schema else table
        op.execute(f"DO $$ BEGIN ALTER TABLE {q} DROP CONSTRAINT IF EXISTS {constraint}; END $$;")


# ============================================================
# UPGRADE
# ============================================================
def upgrade() -> None:
    # --------------------------------------------------------
    # FASE 1: Drop todas las FKs de tablas tenant
    # --------------------------------------------------------
    fks_to_drop = [
        # Empresa
        ('empresas', 'empresas_tenant_id_fkey'),
        ('empresas', 'empresas_regimen_fiscal_id_fkey'),
        ('empresas', 'empresas_tipo_persona_id_fkey'),
        ('empresas', 'empresas_actividad_economica_id_fkey'),
        ('empresas', 'empresas_cuenta_utilidad_periodo_id_fkey'),
        ('empresas', 'empresas_cuenta_utilidades_acumuladas_id_fkey'),
        # Domicilio
        ('domicilios', 'domicilios_empresa_id_fkey'),
        ('domicilios', 'domicilios_tipo_domicilio_id_fkey'),
        ('domicilios', 'domicilios_departamento_id_fkey'),
        ('domicilios', 'domicilios_municipio_id_fkey'),
        # RepresentanteLegal
        ('representantes_legales', 'representantes_legales_empresa_id_fkey'),
        # CuentaContable
        ('plan_cuentas', 'plan_cuentas_empresa_id_fkey'),
        ('plan_cuentas', 'plan_cuentas_cuenta_padre_id_fkey'),
        # Partida
        ('partidas', 'partidas_empresa_id_fkey'),
        ('partidas', 'partidas_partida_reversion_id_fkey'),
        # DetallePartida
        ('detalle_partidas', 'detalle_partidas_partida_id_fkey'),
        ('detalle_partidas', 'detalle_partidas_cuenta_id_fkey'),
        # Secuencia
        ('secuencias', 'secuencias_empresa_id_fkey'),
        # PeriodoFiscal
        ('periodos_fiscales', 'periodos_fiscales_empresa_id_fkey'),
        # FacturaElectronica
        ('facturas_electronicas', 'facturas_electronicas_empresa_id_fkey'),
        ('facturas_electronicas', 'facturas_electronicas_tipo_documento_id_fkey'),
        ('facturas_electronicas', 'facturas_electronicas_moneda_id_fkey'),
        # FacturaImpuestoEspecial
        ('facturas_impuestos_especiales', 'facturas_impuestos_especiales_factura_id_fkey'),
        ('facturas_impuestos_especiales', 'facturas_impuestos_especiales_catalogo_id_fkey'),
        # FacturaDetalle
        ('factura_detalles', 'factura_detalles_factura_id_fkey'),
        # SatLibro
        ('sat_libros', 'sat_libros_empresa_id_fkey'),
        ('sat_libros', 'sat_libros_tipo_libro_id_fkey'),
        ('sat_libros', 'sat_libros_regimen_fiscal_id_fkey'),
        ('sat_libros', 'sat_libros_estado_id_fkey'),
        # SatLibroLinea
        ('sat_libros_lineas', 'sat_libros_lineas_libro_id_fkey'),
        # ActivoFijo
        ('activos_fijos', 'activos_fijos_empresa_id_fkey'),
        ('activos_fijos', 'activos_fijos_categoria_id_fkey'),
        ('activos_fijos', 'activos_fijos_cuenta_gasto_id_fkey'),
        ('activos_fijos', 'activos_fijos_cuenta_depreciacion_acumulada_id_fkey'),
        # DepreciacionActivo
        ('depreciacion_activos', 'depreciacion_activos_empresa_id_fkey'),
        ('depreciacion_activos', 'depreciacion_activos_activo_id_fkey'),
        ('depreciacion_activos', 'depreciacion_activos_partida_id_fkey'),
        # DeclaracionImpuesto
        ('declaraciones_impuesto', 'declaraciones_impuesto_empresa_id_fkey'),
        ('declaraciones_impuesto', 'declaraciones_impuesto_formulario_sat_id_fkey'),
        # DetalleDeclaracionImpuesto
        ('detalles_declaracion_impuesto', 'detalles_declaracion_impuesto_declaracion_id_fkey'),
        ('detalles_declaracion_impuesto', 'detalles_declaracion_impuesto_casilla_sat_id_fkey'),
        # DeclaracionImpuestoFactura
        ('declaraciones_impuesto_facturas', 'declaraciones_impuesto_facturas_detalle_declaracion_id_fkey'),
        ('declaraciones_impuesto_facturas', 'declaraciones_impuesto_facturas_factura_id_fkey'),
    ]
    for tbl, fk in fks_to_drop:
        _drop_fk(op, tbl, fk)

    # Drop FKs de auditoría
    audit_tables = [
        'empresas', 'domicilios', 'representantes_legales', 'plan_cuentas',
        'partidas', 'detalle_partidas', 'periodos_fiscales',
        'facturas_electronicas', 'facturas_impuestos_especiales', 'factura_detalles',
        'sat_libros', 'sat_libros_lineas', 'activos_fijos', 'depreciacion_activos',
        'declaraciones_impuesto', 'detalles_declaracion_impuesto', 'declaraciones_impuesto_facturas'
    ]
    for tbl in audit_tables:
        _drop_fk(op, tbl, f'{tbl}_created_by_fkey')
        _drop_fk(op, tbl, f'{tbl}_updated_by_fkey')

    # --------------------------------------------------------
    # FASE 2: Refactorizar PKs
    # --------------------------------------------------------
    tables_tenant = [
        'empresas', 'domicilios', 'representantes_legales',
        'plan_cuentas', 'partidas', 'detalle_partidas', 'secuencias', 'periodos_fiscales',
        'facturas_electronicas', 'facturas_impuestos_especiales', 'factura_detalles',
        'sat_libros', 'sat_libros_lineas',
        'activos_fijos', 'depreciacion_activos',
        'declaraciones_impuesto', 'detalles_declaracion_impuesto', 'declaraciones_impuesto_facturas'
    ]
    for t in tables_tenant:
        _refactor_pk(op, t)

    # --------------------------------------------------------
    # FASE 3: Cambiar tipos de columnas FK
    # --------------------------------------------------------
    fk_cols = [
        # Empresa
        ('empresas', 'tenant_id'),
        ('empresas', 'regimen_fiscal_id'),
        ('empresas', 'tipo_persona_id'),
        ('empresas', 'actividad_economica_id'),
        ('empresas', 'cuenta_utilidad_periodo_id'),
        ('empresas', 'cuenta_utilidades_acumuladas_id'),
        # Domicilio
        ('domicilios', 'empresa_id'),
        ('domicilios', 'tipo_domicilio_id'),
        ('domicilios', 'departamento_id'),
        ('domicilios', 'municipio_id'),
        # RepresentanteLegal
        ('representantes_legales', 'empresa_id'),
        # CuentaContable
        ('plan_cuentas', 'empresa_id'),
        ('plan_cuentas', 'cuenta_padre_id'),
        # Partida
        ('partidas', 'empresa_id'),
        ('partidas', 'partida_reversion_id'),
        # DetallePartida
        ('detalle_partidas', 'partida_id'),
        ('detalle_partidas', 'cuenta_id'),
        # Secuencia
        ('secuencias', 'empresa_id'),
        # PeriodoFiscal
        ('periodos_fiscales', 'empresa_id'),
        # FacturaElectronica
        ('facturas_electronicas', 'empresa_id'),
        ('facturas_electronicas', 'tipo_documento_id'),
        ('facturas_electronicas', 'moneda_id'),
        # FacturaImpuestoEspecial
        ('facturas_impuestos_especiales', 'factura_id'),
        ('facturas_impuestos_especiales', 'catalogo_id'),
        # FacturaDetalle
        ('factura_detalles', 'factura_id'),
        # SatLibro
        ('sat_libros', 'empresa_id'),
        ('sat_libros', 'tipo_libro_id'),
        ('sat_libros', 'regimen_fiscal_id'),
        ('sat_libros', 'estado_id'),
        ('sat_libros', 'finalizado_por'),
        # SatLibroLinea
        ('sat_libros_lineas', 'libro_id'),
        # ActivoFijo
        ('activos_fijos', 'empresa_id'),
        ('activos_fijos', 'categoria_id'),
        ('activos_fijos', 'cuenta_gasto_id'),
        ('activos_fijos', 'cuenta_depreciacion_acumulada_id'),
        # DepreciacionActivo
        ('depreciacion_activos', 'empresa_id'),
        ('depreciacion_activos', 'activo_id'),
        ('depreciacion_activos', 'partida_id'),
        # DeclaracionImpuesto
        ('declaraciones_impuesto', 'empresa_id'),
        ('declaraciones_impuesto', 'formulario_sat_id'),
        ('declaraciones_impuesto', 'finalizado_por'),
        # DetalleDeclaracionImpuesto
        ('detalles_declaracion_impuesto', 'declaracion_id'),
        ('detalles_declaracion_impuesto', 'casilla_sat_id'),
        ('detalles_declaracion_impuesto', 'ajustado_por'),
        # DeclaracionImpuestoFactura
        ('declaraciones_impuesto_facturas', 'detalle_declaracion_id'),
        ('declaraciones_impuesto_facturas', 'factura_id'),
    ]
    for tbl, col in fk_cols:
        _change_col_to_bigint(op, tbl, col)

    # --------------------------------------------------------
    # FASE 4: Agregar SoftDelete + Audit según cada modelo
    # --------------------------------------------------------
    # Empresa: tenía is_active + created_at
    _add_soft_delete(op, 'empresas', had_is_active=True)
    _add_auditable_full(op, 'empresas', drop_created_at=True)

    # Domicilio: tenía AuditableFull (created_at, updated_at, created_by, updated_by)
    _add_soft_delete(op, 'domicilios')
    _add_auditable_full(op, 'domicilios')

    # RepresentanteLegal: tenía es_activo + created_at
    _add_soft_delete(op, 'representantes_legales', had_es_activo=True)
    _add_auditable_create(op, 'representantes_legales', drop_created_at=True)
    # Nota: el modelo nuevo simplifica tipo_identificacion/numero_identificacion → dpi
    # Si quieres mantener compatibilidad, agrega la columna dpi y elimina las otras:
    op.add_column('representantes_legales', sa.Column('dpi', sa.String(20), nullable=True), schema=None)
    op.execute("UPDATE representantes_legales SET dpi = numero_identificacion WHERE tipo_identificacion = 'DPI'")
    op.alter_column('representantes_legales', 'dpi', nullable=False)
    op.drop_column('representantes_legales', 'tipo_identificacion')
    op.drop_column('representantes_legales', 'numero_identificacion')

    # CuentaContable: tenía activa + created_at
    _add_soft_delete(op, 'plan_cuentas', had_activa=True)
    _add_auditable_full(op, 'plan_cuentas', drop_created_at=True)

    # Partida: tenía is_active + created_at → NO SoftDelete, solo AuditableFull
    op.drop_column('partidas', 'is_active')
    _add_auditable_full(op, 'partidas', drop_created_at=True)

    # DetallePartida: tenía is_active → NO SoftDelete, solo AuditableFull
    op.drop_column('detalle_partidas', 'is_active')
    _add_auditable_full(op, 'detalle_partidas')

    # Secuencia: sin audit, sin soft delete (solo PK refactor)

    # PeriodoFiscal: tenía created_at → AuditableFull
    _add_auditable_full(op, 'periodos_fiscales', drop_created_at=True)

    # FacturaElectronica: tenía created_at → NO SoftDelete, AuditableFull
    _add_auditable_full(op, 'facturas_electronicas', drop_created_at=True)

    # FacturaImpuestoEspecial → AuditableFull
    _add_auditable_full(op, 'facturas_impuestos_especiales')

    # FacturaDetalle → AuditableFull
    _add_auditable_full(op, 'factura_detalles')

    # SatLibro: tenía creado_el, finalizado_por (UUID) → AuditableFull
    op.drop_column('sat_libros', 'creado_el')
    _add_auditable_full(op, 'sat_libros')

    # SatLibroLinea → AuditableFull
    _add_auditable_full(op, 'sat_libros_lineas')

    # ActivoFijo: tenía created_at + updated_at → SoftDelete + AuditableFull
    _add_soft_delete(op, 'activos_fijos')
    op.drop_column('activos_fijos', 'created_at')
    op.drop_column('activos_fijos', 'updated_at')
    op.add_column('activos_fijos', sa.Column('created_by', sa.BigInteger(),
                                             sa.ForeignKey('public.users.id', ondelete='SET NULL'),
                                             nullable=True))
    op.add_column('activos_fijos', sa.Column('updated_by', sa.BigInteger(),
                                             sa.ForeignKey('public.users.id', ondelete='SET NULL'),
                                             nullable=True))

    # DepreciacionActivo: tenía created_at → AuditableFull
    _add_auditable_full(op, 'depreciacion_activos', drop_created_at=True)

    # DeclaracionImpuesto: ya tenía AuditableFull
    _add_auditable_full(op, 'declaraciones_impuesto')

    # DetalleDeclaracionImpuesto: ya tenía AuditableFull
    _add_auditable_full(op, 'detalles_declaracion_impuesto')

    # DeclaracionImpuestoFactura: ya tenía AuditableFull
    _add_auditable_full(op, 'declaraciones_impuesto_facturas')

    # --------------------------------------------------------
    # FASE 5: Recrear todas las FKs
    # --------------------------------------------------------
    fks_to_create = [
        # Empresa
        ('empresas_tenant_id_fkey', 'empresas', 'tenants', ['tenant_id'], ['id'], None, 'public'),
        ('empresas_regimen_fiscal_id_fkey', 'empresas', 'regimenes_fiscales', ['regimen_fiscal_id'], ['id'], None, 'public'),
        ('empresas_tipo_persona_id_fkey', 'empresas', 'tipos_persona', ['tipo_persona_id'], ['id'], None, 'public'),
        ('empresas_actividad_economica_id_fkey', 'empresas', 'actividades_economicas_sat', ['actividad_economica_id'], ['id'], None, 'public'),
        ('empresas_cuenta_utilidad_periodo_id_fkey', 'empresas', 'plan_cuentas', ['cuenta_utilidad_periodo_id'], ['id'], None, None),
        ('empresas_cuenta_utilidades_acumuladas_id_fkey', 'empresas', 'plan_cuentas', ['cuenta_utilidades_acumuladas_id'], ['id'], None, None),
        # Domicilio
        ('domicilios_empresa_id_fkey', 'domicilios', 'empresas', ['empresa_id'], ['id'], None, None),
        ('domicilios_tipo_domicilio_id_fkey', 'domicilios', 'tipos_domicilio', ['tipo_domicilio_id'], ['id'], None, 'public'),
        ('domicilios_departamento_id_fkey', 'domicilios', 'departamentos', ['departamento_id'], ['id'], None, 'public'),
        ('domicilios_municipio_id_fkey', 'domicilios', 'municipios', ['municipio_id'], ['id'], None, 'public'),
        # RepresentanteLegal
        ('representantes_legales_empresa_id_fkey', 'representantes_legales', 'empresas', ['empresa_id'], ['id'], None, None),
        # CuentaContable
        ('plan_cuentas_empresa_id_fkey', 'plan_cuentas', 'empresas', ['empresa_id'], ['id'], None, None),
        ('plan_cuentas_cuenta_padre_id_fkey', 'plan_cuentas', 'plan_cuentas', ['cuenta_padre_id'], ['id'], None, None),
        # Partida
        ('partidas_empresa_id_fkey', 'partidas', 'empresas', ['empresa_id'], ['id'], None, None),
        ('partidas_partida_reversion_id_fkey', 'partidas', 'partidas', ['partida_reversion_id'], ['id'], None, None),
        # DetallePartida
        ('detalle_partidas_partida_id_fkey', 'detalle_partidas', 'partidas', ['partida_id'], ['id'], 'CASCADE', None),
        ('detalle_partidas_cuenta_id_fkey', 'detalle_partidas', 'plan_cuentas', ['cuenta_id'], ['id'], None, None),
        # Secuencia
        ('secuencias_empresa_id_fkey', 'secuencias', 'empresas', ['empresa_id'], ['id'], None, None),
        # PeriodoFiscal
        ('periodos_fiscales_empresa_id_fkey', 'periodos_fiscales', 'empresas', ['empresa_id'], ['id'], None, None),
        # FacturaElectronica
        ('facturas_electronicas_empresa_id_fkey', 'facturas_electronicas', 'empresas', ['empresa_id'], ['id'], None, None),
        ('facturas_electronicas_tipo_documento_id_fkey', 'facturas_electronicas', 'tipos_dte', ['tipo_documento_id'], ['id'], None, 'public'),
        ('facturas_electronicas_moneda_id_fkey', 'facturas_electronicas', 'catalogo_monedas', ['moneda_id'], ['id'], None, 'public'),
        # FacturaImpuestoEspecial
        ('facturas_impuestos_especiales_factura_id_fkey', 'facturas_impuestos_especiales', 'facturas_electronicas', ['factura_id'], ['id'], None, None),
        ('facturas_impuestos_especiales_catalogo_id_fkey', 'facturas_impuestos_especiales', 'catalogo_impuestos_especiales', ['catalogo_id'], ['id'], None, 'public'),
        # FacturaDetalle
        ('factura_detalles_factura_id_fkey', 'factura_detalles', 'facturas_electronicas', ['factura_id'], ['id'], 'CASCADE', None),
        # SatLibro
        ('sat_libros_empresa_id_fkey', 'sat_libros', 'empresas', ['empresa_id'], ['id'], 'RESTRICT', None),
        ('sat_libros_tipo_libro_id_fkey', 'sat_libros', 'tipos_libro', ['tipo_libro_id'], ['id'], None, 'public'),
        ('sat_libros_regimen_fiscal_id_fkey', 'sat_libros', 'regimenes_fiscales', ['regimen_fiscal_id'], ['id'], None, 'public'),
        ('sat_libros_estado_id_fkey', 'sat_libros', 'estados_libro', ['estado_id'], ['id'], None, 'public'),
        # SatLibroLinea
        ('sat_libros_lineas_libro_id_fkey', 'sat_libros_lineas', 'sat_libros', ['libro_id'], ['id'], 'CASCADE', None),
        # ActivoFijo
        ('activos_fijos_empresa_id_fkey', 'activos_fijos', 'empresas', ['empresa_id'], ['id'], None, None),
        ('activos_fijos_categoria_id_fkey', 'activos_fijos', 'categorias_activos_fijos', ['categoria_id'], ['id'], None, 'public'),
        ('activos_fijos_cuenta_gasto_id_fkey', 'activos_fijos', 'plan_cuentas', ['cuenta_gasto_id'], ['id'], None, None),
        ('activos_fijos_cuenta_depreciacion_acumulada_id_fkey', 'activos_fijos', 'plan_cuentas', ['cuenta_depreciacion_acumulada_id'], ['id'], None, None),
        # DepreciacionActivo
        ('depreciacion_activos_empresa_id_fkey', 'depreciacion_activos', 'empresas', ['empresa_id'], ['id'], None, None),
        ('depreciacion_activos_activo_id_fkey', 'depreciacion_activos', 'activos_fijos', ['activo_id'], ['id'], None, None),
        ('depreciacion_activos_partida_id_fkey', 'depreciacion_activos', 'partidas', ['partida_id'], ['id'], None, None),
        # DeclaracionImpuesto
        ('declaraciones_impuesto_empresa_id_fkey', 'declaraciones_impuesto', 'empresas', ['empresa_id'], ['id'], None, None),
        ('declaraciones_impuesto_formulario_sat_id_fkey', 'declaraciones_impuesto', 'formularios_sat', ['formulario_sat_id'], ['id'], None, 'public'),
        # DetalleDeclaracionImpuesto
        ('detalles_declaracion_impuesto_declaracion_id_fkey', 'detalles_declaracion_impuesto', 'declaraciones_impuesto', ['declaracion_id'], ['id'], 'CASCADE', None),
        ('detalles_declaracion_impuesto_casilla_sat_id_fkey', 'detalles_declaracion_impuesto', 'casillas_sat', ['casilla_sat_id'], ['id'], None, 'public'),
        # DeclaracionImpuestoFactura
        ('declaraciones_impuesto_facturas_detalle_declaracion_id_fkey', 'declaraciones_impuesto_facturas', 'detalles_declaracion_impuesto', ['detalle_declaracion_id'], ['id'], 'CASCADE', None),
        ('declaraciones_impuesto_facturas_factura_id_fkey', 'declaraciones_impuesto_facturas', 'facturas_electronicas', ['factura_id'], ['id'], None, None),
    ]
    for name, src_table, ref_table, src_cols, ref_cols, ondelete, ref_schema in fks_to_create:
        kwargs = {
            'source_schema': None,
            'referent_schema': ref_schema,
        }
        if ondelete:
            kwargs['ondelete'] = ondelete
        op.create_foreign_key(name, src_table, ref_table, src_cols, ref_cols, **kwargs)

    # --------------------------------------------------------
    # FASE 6: Eliminar old_uuid_id
    # --------------------------------------------------------
    for t in tables_tenant:
        op.drop_column(t, 'old_uuid_id')


# ============================================================
# DOWNGRADE
# ============================================================
def downgrade() -> None:
    # --------------------------------------------------------
    # FASE 1: Drop FKs actuales
    # --------------------------------------------------------
    fks_to_drop = [fk[0] for fk in [
        ('empresas_tenant_id_fkey',), ('empresas_regimen_fiscal_id_fkey',),
        ('empresas_tipo_persona_id_fkey',), ('empresas_actividad_economica_id_fkey',),
        ('empresas_cuenta_utilidad_periodo_id_fkey',), ('empresas_cuenta_utilidades_acumuladas_id_fkey',),
        ('domicilios_empresa_id_fkey',), ('domicilios_tipo_domicilio_id_fkey',),
        ('domicilios_departamento_id_fkey',), ('domicilios_municipio_id_fkey',),
        ('representantes_legales_empresa_id_fkey',),
        ('plan_cuentas_empresa_id_fkey',), ('plan_cuentas_cuenta_padre_id_fkey',),
        ('partidas_empresa_id_fkey',), ('partidas_partida_reversion_id_fkey',),
        ('detalle_partidas_partida_id_fkey',), ('detalle_partidas_cuenta_id_fkey',),
        ('secuencias_empresa_id_fkey',), ('periodos_fiscales_empresa_id_fkey',),
        ('facturas_electronicas_empresa_id_fkey',), ('facturas_electronicas_tipo_documento_id_fkey',),
        ('facturas_electronicas_moneda_id_fkey',),
        ('facturas_impuestos_especiales_factura_id_fkey',), ('facturas_impuestos_especiales_catalogo_id_fkey',),
        ('factura_detalles_factura_id_fkey',),
        ('sat_libros_empresa_id_fkey',), ('sat_libros_tipo_libro_id_fkey',),
        ('sat_libros_regimen_fiscal_id_fkey',), ('sat_libros_estado_id_fkey',),
        ('sat_libros_lineas_libro_id_fkey',),
        ('activos_fijos_empresa_id_fkey',), ('activos_fijos_categoria_id_fkey',),
        ('activos_fijos_cuenta_gasto_id_fkey',), ('activos_fijos_cuenta_depreciacion_acumulada_id_fkey',),
        ('depreciacion_activos_empresa_id_fkey',), ('depreciacion_activos_activo_id_fkey',),
        ('depreciacion_activos_partida_id_fkey',),
        ('declaraciones_impuesto_empresa_id_fkey',), ('declaraciones_impuesto_formulario_sat_id_fkey',),
        ('detalles_declaracion_impuesto_declaracion_id_fkey',), ('detalles_declaracion_impuesto_casilla_sat_id_fkey',),
        ('declaraciones_impuesto_facturas_detalle_declaracion_id_fkey',), ('declaraciones_impuesto_facturas_factura_id_fkey',),
    ]]
    for fk in fks_to_drop:
        tbl = fk.split('_')[0] if '_' in fk else fk
        _drop_fk(op, tbl, fk)

    # Drop audit FKs
    audit_tables = [
        'empresas', 'domicilios', 'representantes_legales', 'plan_cuentas',
        'partidas', 'detalle_partidas', 'periodos_fiscales',
        'facturas_electronicas', 'facturas_impuestos_especiales', 'factura_detalles',
        'sat_libros', 'sat_libros_lineas', 'activos_fijos', 'depreciacion_activos',
        'declaraciones_impuesto', 'detalles_declaracion_impuesto', 'declaraciones_impuesto_facturas'
    ]
    for tbl in audit_tables:
        _drop_fk(op, tbl, f'{tbl}_created_by_fkey')
        _drop_fk(op, tbl, f'{tbl}_updated_by_fkey')

    # --------------------------------------------------------
    # FASE 2: Drop columnas de mixins
    # --------------------------------------------------------
    # Drop deleted_at (SoftDelete)
    soft_delete_tables = ['empresas', 'domicilios', 'representantes_legales',
                          'plan_cuentas', 'activos_fijos']
    for tbl in soft_delete_tables:
        op.drop_column(tbl, 'deleted_at')

    # Drop created_by + updated_by (AuditableFull)
    for tbl in audit_tables:
        op.drop_column(tbl, 'created_by')
        op.drop_column(tbl, 'updated_by')

    # --------------------------------------------------------
    # FASE 3: Restaurar columnas eliminadas
    # --------------------------------------------------------
    # Empresas: restaurar is_active + created_at
    op.add_column('empresas', sa.Column('is_active', sa.Boolean(), default=True))
    op.add_column('empresas', sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False))

    # RepresentanteLegal: restaurar es_activo + created_at + tipo/numero_identificacion
    op.alter_column('representantes_legales', 'is_active', new_column_name='es_activo')
    op.add_column('representantes_legales', sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()))
    op.add_column('representantes_legales', sa.Column('tipo_identificacion', sa.String(20), nullable=False, server_default='DPI'))
    op.add_column('representantes_legales', sa.Column('numero_identificacion', sa.String(20), nullable=True))
    op.execute("UPDATE representantes_legales SET numero_identificacion = dpi")
    op.alter_column('representantes_legales', 'numero_identificacion', nullable=False)
    op.drop_column('representantes_legales', 'dpi')

    # CuentaContable: restaurar activa + created_at
    op.alter_column('plan_cuentas', 'is_active', new_column_name='activa')
    op.add_column('plan_cuentas', sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()))

    # Partida: restaurar is_active + created_at
    op.add_column('partidas', sa.Column('is_active', sa.Boolean(), nullable=False, server_default='true'))
    op.add_column('partidas', sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()))

    # DetallePartida: restaurar is_active
    op.add_column('detalle_partidas', sa.Column('is_active', sa.Boolean(), nullable=False, server_default='true'))

    # PeriodoFiscal: restaurar created_at
    op.add_column('periodos_fiscales', sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()))

    # FacturaElectronica: restaurar created_at
    op.add_column('facturas_electronicas', sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()))

    # SatLibro: restaurar creado_el
    op.add_column('sat_libros', sa.Column('creado_el', sa.DateTime(timezone=True), server_default=sa.func.now()))

    # ActivoFijo: restaurar created_at + updated_at + drop is_active + deleted_at
    op.add_column('activos_fijos', sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()))
    op.add_column('activos_fijos', sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now()))

    # DepreciacionActivo: restaurar created_at
    op.add_column('depreciacion_activos', sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()))

    # --------------------------------------------------------
    # FASE 4: Revertir PKs (BIGINT → UUID)
    # --------------------------------------------------------
    tables_tenant = [
        'empresas', 'domicilios', 'representantes_legales',
        'plan_cuentas', 'partidas', 'detalle_partidas', 'secuencias', 'periodos_fiscales',
        'facturas_electronicas', 'facturas_impuestos_especiales', 'factura_detalles',
        'sat_libros', 'sat_libros_lineas',
        'activos_fijos', 'depreciacion_activos',
        'declaraciones_impuesto', 'detalles_declaracion_impuesto', 'declaraciones_impuesto_facturas'
    ]
    for t in tables_tenant:
        op.drop_constraint(f"{t}_pkey", t, type_='primary')
        op.drop_index(f"ix_{t}_public_id", table_name=t)
        op.drop_constraint(f"uq_{t}_public_id", t, type_='unique')
        op.drop_column(t, 'id')
        op.drop_column(t, 'public_id')
        op.execute(f"DROP SEQUENCE IF EXISTS {t}_id_seq")
        op.alter_column(t, 'old_uuid_id', new_column_name='id')
        op.create_primary_key(f"{t}_pkey", t, ['id'])

    # --------------------------------------------------------
    # FASE 5: Revertir tipos FK (BigInteger → UUID)
    # --------------------------------------------------------
    fk_cols = [
        ('empresas', 'tenant_id'), ('empresas', 'regimen_fiscal_id'),
        ('empresas', 'tipo_persona_id'), ('empresas', 'actividad_economica_id'),
        ('empresas', 'cuenta_utilidad_periodo_id'), ('empresas', 'cuenta_utilidades_acumuladas_id'),
        ('domicilios', 'empresa_id'), ('domicilios', 'tipo_domicilio_id'),
        ('domicilios', 'departamento_id'), ('domicilios', 'municipio_id'),
        ('representantes_legales', 'empresa_id'),
        ('plan_cuentas', 'empresa_id'), ('plan_cuentas', 'cuenta_padre_id'),
        ('partidas', 'empresa_id'), ('partidas', 'partida_reversion_id'),
        ('detalle_partidas', 'partida_id'), ('detalle_partidas', 'cuenta_id'),
        ('secuencias', 'empresa_id'), ('periodos_fiscales', 'empresa_id'),
        ('facturas_electronicas', 'empresa_id'), ('facturas_electronicas', 'tipo_documento_id'),
        ('facturas_electronicas', 'moneda_id'),
        ('facturas_impuestos_especiales', 'factura_id'), ('facturas_impuestos_especiales', 'catalogo_id'),
        ('factura_detalles', 'factura_id'),
        ('sat_libros', 'empresa_id'), ('sat_libros', 'tipo_libro_id'),
        ('sat_libros', 'regimen_fiscal_id'), ('sat_libros', 'estado_id'), ('sat_libros', 'finalizado_por'),
        ('sat_libros_lineas', 'libro_id'),
        ('activos_fijos', 'empresa_id'), ('activos_fijos', 'categoria_id'),
        ('activos_fijos', 'cuenta_gasto_id'), ('activos_fijos', 'cuenta_depreciacion_acumulada_id'),
        ('depreciacion_activos', 'empresa_id'), ('depreciacion_activos', 'activo_id'),
        ('depreciacion_activos', 'partida_id'),
        ('declaraciones_impuesto', 'empresa_id'), ('declaraciones_impuesto', 'formulario_sat_id'),
        ('declaraciones_impuesto', 'finalizado_por'),
        ('detalles_declaracion_impuesto', 'declaracion_id'), ('detalles_declaracion_impuesto', 'casilla_sat_id'),
        ('detalles_declaracion_impuesto', 'ajustado_por'),
        ('declaraciones_impuesto_facturas', 'detalle_declaracion_id'), ('declaraciones_impuesto_facturas', 'factura_id'),
    ]
    for tbl, col in fk_cols:
        op.alter_column(tbl, col, type_=UUID(as_uuid=True), existing_type=sa.BigInteger())

    # --------------------------------------------------------
    # FASE 6: Recrear FKs originales (simplificado - mismo patrón que upgrade)
    # --------------------------------------------------------
    # (Mismas FKs que en la versión original UUID → UUID)
    # Replicar aquí el bloque de create_foreign_key del upgrade pero con UUID
    # Por brevedad, se omite la repetición completa - seguir el mismo patrón
    op.create_foreign_key('empresas_tenant_id_fkey', 'empresas', 'tenants', ['tenant_id'], ['id'], referent_schema='public')
    # ... (repetir para todas las FKs originales)

